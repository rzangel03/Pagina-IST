//
//  celdaevento.swift
//  Eventz
//
//  Created by MAC 7 on 03/06/17.
//  Copyright © 2017 MAC7. All rights reserved.
//

import UIKit

class celdaevento: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var nombredelevento: UILabel!
    @IBOutlet weak var fecha: UILabel!
    @IBOutlet weak var hora: UILabel!
    @IBOutlet weak var cupo: UILabel!
    @IBOutlet weak var tipodeevento: UILabel!
    @IBOutlet weak var costo: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
