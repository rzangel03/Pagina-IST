//
//  TablaEventosController.swift
//  Eventz
//
//  Created by MAC 7 on 03/06/17.
//  Copyright © 2017 MAC7. All rights reserved.
//

import UIKit


class TablaEventosController: UITableViewController {
    let dateFormatter = DateFormatter()
    
    @IBOutlet weak var indicador: UIActivityIndicatorView!
    override func viewDidLoad() {
        
        dateFormatter.dateFormat = "yyyy-dd-MM"
        
    }

    var renglon: Int = -1
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        
        renglon = -1
        iniciarIndicador()
        leerEventos("http://eventzprogmovil2.azurewebsites.net/listaeventos.php")
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        renglon = indexPath.row
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return eventos.count
    }

   //MARK: Aqui se ejecuta el método que llena cada celda a partir del xib
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("celdaevento", owner: self, options: nil)?.first as! celdaevento
        var tipoEvento = ""
        //let fecha = String(describing: eventos[indexPath.row].fecha)
        cell.nombredelevento.text = eventos[indexPath.row].nombreevento
        cell.costo.text = String(eventos[indexPath.row].costo)
        cell.cupo.text = String(eventos[indexPath.row].cupo)
        cell.fecha.text = eventos[indexPath.row].fecha.datePart()
        cell.hora.text = eventos[indexPath.row].hora
        cell.img.image = eventos[indexPath.row].imagen
        switch eventos[indexPath.row].tipo {
        case 1:
            tipoEvento = "Convención"
            break;
        case 2:
            tipoEvento = "Exposición"
            break;
        case 3:
            tipoEvento = "Fiesta"
            break;
        default: break
        }
        cell.tipodeevento.text = tipoEvento
        
        tableView.rowHeight = cell.frame.height
        let doubletap = UITapGestureRecognizer(target:self, action: #selector(eliminar(_:)))
        doubletap.numberOfTapsRequired = 2
        cell.addGestureRecognizer(doubletap)
        
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(modificarDatos(_:)))
        longPress.minimumPressDuration = 1.0
        cell.addGestureRecognizer(longPress)
        return cell
        
    }
    //MARK: Aqui se elimina un evento que se ejecuta mediante un doble tap
    func eliminar(_ tap: UITapGestureRecognizer){
    
        let id = eventos[renglon].id
        print(id)
        let alerta = UIAlertController(title: "Confirmación", message: "Desea eliminar el registro?", preferredStyle: .alert)
        
        let btnSI = UIAlertAction(title: "SI", style: .destructive)
        {
            (action:UIAlertAction) in
            self.eliminarEvento("http://eventzprogmovil2.azurewebsites.net/borrar_evento_creado.php", id)
        }
        
        let btnNO = UIAlertAction(title: "NO", style: .cancel)
        
        alerta.addAction(btnSI)
        alerta.addAction(btnNO)
        self.present(alerta, animated: true, completion:nil)
    }
    
    func eliminarEvento(_ liga: String, _ eventoid: Int)
    {
        
        let parametrosPost = "user=default&evento=\(eventoid)&"

        let url = URL(string: liga)!
        print(url)
        
        var peticion = URLRequest(url: url)
        peticion.httpMethod = "POST"
        
        peticion.httpBody = parametrosPost.data(using: String.Encoding.utf8)
        let tarea = URLSession.shared.dataTask(with: peticion)
        {
            (data, response, error) in
            if error != nil
            {
                let Error = error as! NSError
                print(Error)
            }
        }
        DispatchQueue.main.async(execute: {self.viewWillAppear(true)})
        tarea.resume()
    }

    
    
    
    //MARK: Aqui se llena el arreglo de eventos mediante el webservice
    func leerEventos(_ liga: String)
    {
        let parametros = "tipo=0&user=default&"
        let url = URL(string: liga)!
        var peticion = URLRequest(url: url)
        peticion.httpMethod = "POST"
        
        peticion.httpBody = parametros.data(using: String.Encoding.utf8)
        let tarea = URLSession.shared.dataTask(with: peticion)
        {
            (data, response, error) in
            if error == nil
            {
                self.deserializarEventos(data!)
            }
            else
            {
                let Error = error as! NSError
                print(Error)
            }
        }
        tarea.resume()
    }
    
    func deserializarEventos(_ data: Data)
    {
        var img: UIImage!
        do
        {
            let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as AnyObject
            let arreglo_json = json as? NSArray
            eventos.removeAll()
            for i in 0 ..< arreglo_json!.count
            {
                let dato_json = arreglo_json?[i] as? NSArray
                let id = Int((dato_json?[0] as? String)!)
                let nombre = dato_json?[1] as? String
                //let fecha = dateFormatter.date(from: (dato_json?[2] as? String)!)
                let formato = DateFormatter()
                formato.locale = Locale(identifier:"en_US_POSIX")
                formato.dateFormat = "yyyy-MM-dd"
                //formato.timeZone = TimeZone(forSecondsFromGT: 0)
                let fecha = formato.date(from: dato_json?[2] as! String)
                let hora = dato_json?[3] as? String
                let lugar = dato_json?[4] as? String
                let cupo = Int((dato_json?[5] as? String)!)
                let tipo = Int((dato_json?[10] as? String)!)
                let costo = Double((dato_json?[6] as? String)!)
                let descripcion = dato_json?[7] as? String
                
                
                switch tipo! {
                case 1:
                    img = #imageLiteral(resourceName: "Tipos/convencion")
                    break;
                case 2:
                    img = #imageLiteral(resourceName: "Tipos/exposicion")
                    break;
                case 3:
                    img = #imageLiteral(resourceName: "Tipos/fiesta")
                    break;
                default: break
                }


                eventos.append(evento(id:id!,nombreevento: nombre!,fecha: fecha!,hora:hora!,lugar:lugar!,cupo:cupo!,tipo:tipo!,costo:costo!, descripcion:descripcion!,imagen:img!))
                
            }

        }
        catch
        {
            let Error = error as NSError
            print(Error)
        }
        
        DispatchQueue.main.async(execute:
            {
                self.tableView.reloadData()
                self.detenerIndicador()
        })
    }
    func iniciarIndicador()
    {
        tableView.backgroundView = indicador
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        indicador.isHidden = false
        indicador.startAnimating()
    }
    
    func detenerIndicador()
    {
        indicador.stopAnimating()
        indicador.isHidden = true
        tableView.separatorStyle = UITableViewCellSeparatorStyle.singleLine
    }
    
    //MARK: Aqui se muestra una alerta para modificar el evento mediante el gesto longpress
    func modificarDatos(_ tap: UILongPressGestureRecognizer)
    {
        let punto = tap.location(in: self.tableView)
        let path = self.tableView.indexPathForRow(at: punto)
        if let indexPath = path
        {
            self.tableView(self.tableView, didSelectRowAt: indexPath)
        }

        
        let alerta = UIAlertController(title: "Modificar", message: "(Lugar, Cupo, Costo, Descripcion)", preferredStyle: .alert)
        
        alerta.addTextField
            {
                (textField) -> Void in
                textField.text = eventos[self.renglon].lugar
        }
        
        alerta.addTextField
            {
                (textField) -> Void in
                textField.text = String(eventos[self.renglon].cupo)
        }
        alerta.addTextField
            {
                (textField) -> Void in
                textField.text = String(eventos[self.renglon].costo)
        }
        alerta.addTextField
            {
                (textField) -> Void in
                textField.text = eventos[self.renglon].descripcion
        }
        
        let btnCancelar = UIAlertAction(title: "Cancelar", style: .cancel)
        
        let btnAceptar = UIAlertAction(title: "Aceptar", style: .default)
        {
            
            (action:UIAlertAction) in
           self.modificarEvento("http://eventzprogmovil2.azurewebsites.net/modificar.php", Int(eventos[self.renglon].id), alerta.textFields![0].text!,Int(alerta.textFields![1].text!)!,Double(alerta.textFields![2].text!)!,alerta.textFields![3].text!)
            
        }
        
        alerta.addAction(btnCancelar)
        alerta.addAction(btnAceptar)
        self.present(alerta, animated: true, completion:nil)
    }

    //TODO: Agregar que se modifique también la hora y fecha
    func modificarEvento(_ liga: String, _ id: Int, _ lugar:String, _ cupo: Int, _ costo: Double, _ desc:String)
    {
        let parametrosPost = "id=\(id)&lugar=\(lugar)&cupo=\(cupo)&costo=\(costo)&descripcion=\(desc)&"
        print(parametrosPost)
        let url = URL(string: liga)!
        
        var peticion = URLRequest(url: url)
        peticion.httpMethod = "POST"
        
        peticion.httpBody = parametrosPost.data(using: String.Encoding.utf8)
        let tarea = URLSession.shared.dataTask(with: peticion)
        {
            (data, response, error) in
            if error != nil
            {
                let Error = error as! NSError
                print(Error)
            }
        }
        DispatchQueue.main.async(execute: {self.viewWillAppear(true)})
        tarea.resume()
    }

}
