//
//  extensionFecha.swift
//  Eventz
//
//  Created by MAC 6 on 05/06/17.
//  Copyright © 2017 MAC7. All rights reserved.
//

import Foundation

extension Date
{
    func datePart() -> String
    {
        var cadenaFecha: String 
        cadenaFecha = self.description
        let index = cadenaFecha.index(cadenaFecha.startIndex, offsetBy: 10)
        return cadenaFecha.substring(to: index)
    }
}

