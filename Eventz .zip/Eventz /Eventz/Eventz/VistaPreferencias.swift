//
//  VistaPreferencias.swift
//  Eventz
//
//  Created by Karla Rodriguez on 06/06/17.
//  Copyright © 2017 MAC7. All rights reserved.
//

import UIKit

class VistaPreferencias: UIViewController {
    
    @IBOutlet weak var txtTexto: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func guardarUserDefaults(){
        /*
         se crea un objeto para guardar las preferencias
         guardar en un archivo cuya estructura es un xml, guarda las preferencias que necesitemos. Al leerlo busca las etiquetas xml.
         La principal diferencia:
         user defaults solo existe una instancia por aplicacion y el nombre se da automaticamente, y los propertylist permine tener n y con el nombre que queramos
         */
        let pref = UserDefaults.standard
        
        /*
         para guardar se usa el metodo set. Se puede guardar cualquier cosa.
         se guardan tipo diccionario, llave:Valor
         
         si se quiere modificar algun valor se sigue usando el set. El set verifica si ya existe, si es asi la modifica sino la crea
         */
        let textoInicio = txtTexto.text!
        print(textoInicio)
        pref.set(textoInicio, forKey: "bienvenida")
        
        pref.synchronize()
        
        txtTexto.text = ""
        
        
        print("Preferencias guardadas")
        
        let alerta = UIAlertController(title: "Exito", message: "Se han guardado las preferencias", preferredStyle: .alert)
        
        
        let btnAceptar = UIAlertAction(title: "Aceptar", style: .default)
        
        alerta.addAction(btnAceptar)
        present(alerta, animated: true, completion:nil)
    }
    
    
    func leerUserDefaults()
    {
        /*
         la construccion del objeto let pref = UserDefaults.standard debe hacerse cada vez que se quiera guardar o leer preferencias
         para leer es la linea 2
         */
        let pref = UserDefaults.standard
        let texto = pref.string(forKey: "bienvenida")
        print(texto!)
    }
    
    func borrarUserDefaults(){
        /*
         sugerencia es no eliminarlas.
         */
        
        let pref = UserDefaults.standard
        pref.removeObject(forKey: "bienvenida")
    }
    
    @IBAction func Guardar(_ sender: UIButton) {
        guardarUserDefaults()
    }
    
    

}
