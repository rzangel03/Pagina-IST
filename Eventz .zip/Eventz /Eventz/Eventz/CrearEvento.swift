//
//  CrearEvento.swift
//  Eventz
//
//  Created by Angel Rodriguez on 06/06/17.
//  Copyright © 2017 MAC7. All rights reserved.
//

import UIKit
import AudioToolbox

class CrearEvento: UIViewController {
    
    @IBOutlet weak var txtdescripcion: UITextField!
    @IBOutlet weak var txtcosto: UITextField!
    @IBOutlet weak var txtcupo: UITextField!
    @IBOutlet weak var txttipodeevento: UISegmentedControl!
    @IBOutlet weak var txtlugar: UITextField!
    @IBOutlet weak var txthora: UIDatePicker!
    @IBOutlet weak var txtfecha: UIDatePicker!
    @IBOutlet weak var txtnombre: UITextField!
    var idevento: String = ""
    var descripcion: String = ""
    var costo: String = ""
    var cupo: String = ""
    var tipodeevento: String = ""
    var lugar: String = ""
    var fecha: String = ""
    var nombre: String = ""
    var hora: String = ""
    override func viewWillAppear(_ animated: Bool) {
        
        txtdescripcion.text = descripcion
        txtcosto.text = costo
        txtcupo.text = cupo
        txtlugar.text = lugar
        txtnombre.text = nombre
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: Aqui se leen los datos de los controles y se manda a llamar el webservice
    @IBAction func btnGuardar(_ sender: Any) {
        
        //Obtener Solo la fecha
        txtfecha.datePickerMode = UIDatePickerMode.date
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        let solofecha = dateformatter.string(from: txtfecha.date)
        //obtener la hora en formato de 12hrs
        txthora.datePickerMode = UIDatePickerMode.time
        //let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm"
        let solohoras = dateformatter.string(from: txthora.date)
        //let date = dateformatter.date(from: solohoras)
        //dateformatter.dateFormat = "h:mm a"
        //let date12 = dateformatter.string(from: date!)
        
            //falta acepta las comillas ' " y obtener la fecha del Datepicker
            
            //print(fecha)
            var tipoindex = (txttipodeevento.selectedSegmentIndex)
            tipoindex += 1
            altaEvento("http://eventzprogmovil2.azurewebsites.net/crearevento.php", txtnombre.text!,solofecha,solohoras,txtlugar.text!,Int(txtcosto.text!)!,tipoindex,Int(txtcosto.text!)!,txtdescripcion.text!)
            tipoindex = 0
        
        
    }
    
    //MARK: Aqui se reciben los parametros que espera el método que invoca al webservice
    func altaEvento(_ liga: String, _ nombre: String,_ fecha: String,_ hora:String, _ lugar: String,_ cupo:Int,_ tipodeevento:Int,_ costo:Int,_ descripcion:String)
    {
        let parametrosPost = "nombre=\(nombre)&fecha=\(fecha)&hora=\(hora)&lugar=\(lugar)&cupo=\(cupo)&tipo=\(tipodeevento)&costo=\(costo)&descripcion=\(descripcion)&"
        print(parametrosPost)
        
        let url = URL(string: liga)!
        
        var peticion = URLRequest(url: url)
        peticion.httpMethod = "POST"
        
        peticion.httpBody = parametrosPost.data(using: String.Encoding.utf8)
        print(peticion)
        let tarea = URLSession.shared.dataTask(with: peticion)
        {
            
            (data, response, error) in
            if error != nil
            {
                let Error = error! as NSError
                print(Error)
            }
        }
        
        let alerta = UIAlertController(title: "Alta exitosa", message: "El registro ha sido agregado", preferredStyle: .alert)
        
        
        let btnAceptar = UIAlertAction(title: "Aceptar", style: .default)
        
        alerta.addAction(btnAceptar)
        self.present(alerta, animated: true, completion:nil)
        txtnombre.text = ""
        txtlugar.text = ""
        txttipodeevento.selectedSegmentIndex = 0
        txtcupo.text = ""
        txtcosto.text = ""
        txtdescripcion.text = ""
        
        tarea.resume()
        AudioServicesPlaySystemSound(SystemSoundID("1075")!)

    }

}
