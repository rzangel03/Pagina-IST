//
//  Evento.swift
//  Eventz
//
//  Created by MAC 7 on 03/06/17.
//  Copyright © 2017 MAC7. All rights reserved.
//

import Foundation
import UIKit
struct evento {
    var id:Int
    var nombreevento:String
    var fecha:Date
    var hora:String
    var lugar:String
    var cupo:Int
    var tipo:Int
    var costo:Double
    var descripcion:String
    var imagen:UIImage!
}
var eventos:[evento] = [evento]()
